# muda pra versão em prod, faz o build e roda como se fosse em prod

pnpm build

pnpm start

# muda pra versão dev

pnpm dev
