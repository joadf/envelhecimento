import Link from 'next/link'

export default function Dashboard() {
  return (
    <div>
      <h1>Auth login</h1>
      <Link href="/">home</Link>
    </div>
  )
}
